class Makanan {
  final String nama;
  final String deskripsi;
  final String gambar;
  final String detail;
  final String waktubuka;
  final String harga;
  final String kalori;
  final List<String> gambarlain;
  final List<Map<String, String>> bahan;

  Makanan(
      {required this.nama,
      required this.harga,
      required this.gambarlain,
      required this.waktubuka,
      required this.detail,
      required this.kalori,
      required this.bahan,
      required this.deskripsi,
      required this.gambar
      });

      static List<Makanan> dummyData = [
        Makanan(
      nama: 'Seblak',
      deskripsi: 'Makanan berkuah',
      gambar: 'assets/Seblak.jpeg',
      detail:
          'Seblak adalah makanan khas Sunda dari Jawa Barat yang terbuat dari kerupuk basah dimasak dengan bumbu pedas, terutama kencur dan cabai. Hidangan ini sering disajikan dengan tambahan telur, sosis, bakso, atau sayuran. Seblak dikenal dengan cita rasa gurih dan pedas serta tekstur kenyal dari kerupuk yang direndam.',
      waktubuka: '07.00-10.00',
      harga: 'Rp 10.000',
      gambarlain: [
        'assets/seblak1.jpeg',
        'assets/seblak2.jpeg',
        'assets/seblak3.jpeg',
      ],
      bahan: [
        {'kencur': 'assets/bahan/kencur.jpeg'},
        {'bawang': 'assets/bahan/bawang.jpeg'},
        {'cabai': 'assets/bahan/cabai.jpeg'},
        {'gula': 'assets/bahan/gula.jpeg'},
        {'garam': 'assets/bahan/garam.jpeg'},
      ],
      kalori: '372 kkal'),
  Makanan(
      nama: 'Rujak',
      deskripsi: 'buah-buahan',
      gambar: 'assets/Rujak.jpeg',
      detail:
          'Rujak adalah makanan sehat.',
      waktubuka: '09.00-12.00',
      harga: 'Rp 6.000',
      gambarlain: [
        'assets/rujak1.jpeg',
        'assets/rujak2.jpeg',
        'assets/rujak3.jpeg',
      ],
      bahan: [
        {'nanas': 'assets/bahan/nanas.jpeg'},
        {'mangga': 'assets/bahan/mangga.jpeg'},
        {'kacang': 'assets/bahan/kacang.jpeg'},
        {'cabai': 'assets/bahan/cabai.jpeg'},
        {'garam': 'assets/bahan/garam.jpeg'},
      ],
      kalori: '400 kkal'),
  Makanan(
      nama: 'Pecel',
      deskripsi: 'Sayuran dengan bumbu kacang',
      gambar: 'assets/pecel.jpg',
      detail:
          'Makanan pecel adalah makanan yang menggunakan bumbu sambal kacang sebagai bahan utamanya yang dicampur dengan aneka jenis sayuran. Asal kata dan daerah pecel belum diketahui secara pasti, tetapi dalam bahasa Jawa, pecel dapat diartikan sebagai “tumbuk” atau dihancurkan dengan cara ditumbuk.',
      waktubuka: '08.00-16.00',
      harga: 'Rp 8.000',
      gambarlain: [
        'assets/pecel1.jpeg',
        'assets/pecel2.jpeg',
        'assets/pecel3.jpeg',
      ],
      bahan: [
        {'kacang': 'assets/bahan/kacang.jpeg'},
        {'bawang': 'assets/bahan/bawang.jpeg'},
        {'cabai': 'assets/bahan/cabai.jpeg'},
        {'kencur': 'assets/bahan/kencur.jpeg'},
        {'gula': 'assets/bahan/gula.jpeg'},
      ],
      kalori: '426 kkal'),
];
}

package com.example.list_kuliner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
